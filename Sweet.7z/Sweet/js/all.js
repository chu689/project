$(document).ready(function() {
  $('.logo_ham').click(function() {
      $('.menu').toggleClass('active');
  });
});